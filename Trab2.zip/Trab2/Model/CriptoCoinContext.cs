﻿using Microsoft.EntityFrameworkCore;

namespace Trab2.Model
{
    public class CriptoCoinContext : DbContext { 
        //Contrutor de Classe
        public CriptoCoinContext(DbContextOptions<CriptoCoinContext> options) : base(options) 
        { }

        //Recurso para manipular itens na base de dados
        public DbSet<CriptoCoin> CriptoCoinItens { get; set; } = null!;

            
    }
}
