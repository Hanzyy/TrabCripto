using Trab2.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;

namespace Trab2
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllers();

            builder.Services.AddDbContext<CriptoCoinContext>(opt =>
                opt.UseInMemoryDatabase("CriptoCoinBD"));

            // Adiciona o Swagger
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "CriptoCoin API",
                    Version = "v1",
                    Description = "API para gerenciamento de criptomoedas"
                });
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "CriptoCoin API v1");
                    c.RoutePrefix = string.Empty;

                    c.HeadContent = @"
                        <style>
                            .topbar-wrapper img {
                                content: url('/swagger-ui/logo.png');
                                height: 40px;
                            }
                            .topbar-wrapper span {
                                display: none;
                            }
                        </style>
                    ";
                })};


                app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
